// EDIT THIS FILE to add your characters, lorebooks, and prompts.
// Replace example.com links with your real published pages.
// Images: add files to an images/ folder and set image: "images/filename.jpg".
window.HUB_DATA = {
  characters: [
    {id:"xerxes-trevan",name:"Xerxes Trevan",category:"The Dominion",symbol:"♛",image:"",summary:"Court Lord of Trevan Hall and Fifth Seat of the Alpha Council.",description:"An influential alpha of the Central Dominion, whose carefully guarded Court operates beneath the weight of political power.",tags:["Alpha","Dark Romance","Political Intrigue"],links:[]},
    {id:"jeremiah-valez",name:"Jeremiah Valez",category:"Dawnwalkers",symbol:"☾",image:"",summary:"An emergency nurse with a monstrous secret after sunset.",description:"A restrained predator struggling against an unrelenting hunger, living in a small city in northern Germany.",tags:["Supernatural","Horror","Slow Burn"],links:[]},
    {id:"lyall",name:"Lyall",category:"Northern Fjordlands",symbol:"❄",image:"",summary:"A hardened scavenger surviving the frozen wilderness.",description:"A solitary survivor shaped by the blizzards, unforgiving terrain, and losses of the Northern Fjordlands.",tags:["Survival","Fantasy","Winter"],links:[]}
  ],
  lorebooks: [
    {id:"dominion-codex",name:"The Dominion Codex",category:"The Dominion",symbol:"♜",image:"",summary:"The laws, designations and power structures of the modern Dominions.",description:"Explore the five mega-city States, their Councils, Courts, and the designation system that defines their civilization.",tags:["Worldbuilding","Omegaverse"],links:[]},
    {id:"old-order",name:"The Old Order",category:"Before the Dominions",symbol:"⚜",image:"",summary:"The kingdoms, clans and beliefs that existed before the Dominions.",description:"A look at the fractured world of ancient bloodlines, rival houses, northern packs and clashing religious powers.",tags:["Prequel","Fantasy"],links:[]},
    {id:"dawnwalkers",name:"Dawnwalkers",category:"Supernatural Horror",symbol:"☽",image:"",summary:"Five unique Originals hidden in a contemporary world.",description:"A supernatural setting grounded in modern-day reality, where the night reveals dangerous truths.",tags:["Horror","Modern"],links:[]}
  ],
  prompts: [
    {id:"stry-trsh",name:"STRY—TRSH",category:"Story-focused",symbol:"✒",image:"",summary:"Immersive third-person storytelling and slow-burn progression.",description:"Narrative focus, proactive world behavior, independent NPCs, spatial awareness and consistent consequences.",tags:["Third Person","Storytelling"],links:[]},
    {id:"dom-trsh",name:"DOM—TRSH",category:"Dominant / NSFW-focused",symbol:"◆",image:"",summary:"A model focused on dominant character portrayal.",description:"Explore this model's character-focused interactions and roleplay style.",tags:["Roleplay"],links:[]},
    {id:"rpg-trsh",name:"RPG—TRSH",category:"Balanced",symbol:"✧",image:"",summary:"Balanced roleplay with world and character progression.",description:"A general-purpose approach to interactive roleplay and responsive storytelling.",tags:["RPG","Balanced"],links:[]}
  ]
};

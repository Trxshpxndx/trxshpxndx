# Raccoon Hideout — Creator Hub

A mobile-first static website and installable PWA for AI roleplay characters, lorebooks, and prompts.

## Publish with GitHub Pages

1. Create a **public** GitHub repository (for example, `character-hub`).
2. Upload **all the files in this folder** to the root of the repository (not inside a nested `character-hub` folder).
3. Open repository **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, branch **main**, folder **/(root)**, then Save.
5. Visit `https://YOUR-USERNAME.github.io/character-hub/` once deployment finishes.

## Customize

- **Content:** Edit `data.js` to add, change, or remove characters, lorebooks, and prompts.
- **Images:** Upload pictures to an `images` folder and set `image: "images/example.jpg"` in `data.js`.
- **External links:** Add `links: [{label: "Read on platform", url: "https://..."}]` to any entry.
- **Colors:** Change CSS variables at the top of `style.css`.
- **Name and description:** Edit `index.html` and `manifest.webmanifest`.
- **App icons:** Replace `icon-192.png`, `icon-512.png`, and `icon.svg` with your own artwork.
- **Offline cache:** If changes appear stale after deployment, update the cache version in `sw.js` (e.g. `hideout-v2`) and refresh.

GitHub Pages hosts static files, not a backend/database. Public repository content is publicly visible. Install support depends on browser/platform.
